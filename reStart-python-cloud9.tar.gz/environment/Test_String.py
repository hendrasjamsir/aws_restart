Var1=321
String1="789"
Complex1=5+3j
Bool1=True
print(Var1)
print(String1)
print(type(Var1))
print(type(String1))
print(type(str(Var1)+" "+String1))
print(Var1*1000+int(String1))

# DAta Type FLOAT
print(type(Var1*1000+int(String1)))
print(float((Var1*1000+int(String1))))

# DAta Type COMPLEX
print(type(Complex1))
print(Var1+Complex1)

# DAta Type BOOLEAN
print(Bool1)
print(int(Bool1)) 
print(str(Bool1) + " is of the data type " + str(type(Bool1)))

print ("Rubrik 3 Working with the String Data Type")
print ("Ex1")
myString = "This is a string."
print(myString)
print(myString + " is of the data type " + str(type(myString)))

print ("Ex2")
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)

print ("Ex3")
name = input("What is your name? ")
print(name)

print ("Ex4")
color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))

print("\n")
print ("Rubric: 4 - List, Tuple, Dictionary")

print("\n")
print("Exercise 1: Introducing the list data type")
print("Defining a list")
myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

print("Changing the values in a list")
print(myFruitList[2])
myFruitList[2] = "orange"
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

print("\n")
print("Exercise 2: Introducing the tuple data type")
print("Defining a tuple")
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))
print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])
#myFinalAnswerTuple[2]="Durian"


print("\n")
print("Exercise 3: Introducing the dictionary data type")
myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])

print("\n")
print("Exercise 3B: EXTRA EXTRA Introducing the dictionary data type")
myFavoriteFruitFoodDictionary = {
  "Akua" : {"Fruit":"apple", "Food":"Nandos"},
  "Saanvi" : {"Fruit":"banana", "Food":"KFC"},
  "Paulo" : {"Fruit":"pineapple", "Food":"EatTokyo"},
  "Santa" : {"Fruit":"durian", "Food":"EatTokyo"}
}
print(myFavoriteFruitFoodDictionary)
print(type(myFavoriteFruitFoodDictionary))
print(myFavoriteFruitFoodDictionary["Akua"])
print(myFavoriteFruitFoodDictionary["Saanvi"])
print(myFavoriteFruitFoodDictionary["Paulo"])
print(myFavoriteFruitFoodDictionary["Akua"]["Fruit"])
print(myFavoriteFruitFoodDictionary["Akua"]["Food"])
print(myFavoriteFruitFoodDictionary["Santa"]["Fruit"])

print("\n")
print("Rubric: 5 - Categorize Values")
print("Categorizing Values")

print("\n")
print("Exercise 1: Creating a mixed-type list")
myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45"]
for item in myMixedTypeList:
    print("{} is of the data type {}".format(item,type(item)))
    
for item in myFavoriteFruitFoodDictionary["Akua"]:
   print("{} is of the data type {}".format(item,type(item)))

print("\n")
print("Rubric: 6 - Composite Data Types")
print("Working with Composite Data Types")   
print("Creating a car inventory data - DONE on separate file")
import csv
import copy

print("Creating a car inventory program")
print("Defining the dictionary")

myVehicle = {
    "vin" : "<empty>",
    "make" : "<empty>" ,
    "model" : "<empty>" ,
    "year" : 0,
    "range" : 0,
    "topSpeed" : 0,
    "zeroSixty" : 0.0,
    "mileage" : 0
}
for key, value in myVehicle.items():
    print("{} : {}".format(key,value))
myInventoryList = []

print("Copying the CSV file into memory")

with open('car_fleet.csv') as csvFile:
    csvReader = csv.reader(csvFile, delimiter=',')  
    lineCount = 0  
    for row in csvReader:
        if lineCount == 0:
            print(f'Column names are: {", ".join(row)}')  
            lineCount += 1  
        else:  
            print(f'vin: {row[0]} make: {row[1]}, model: {row[2]}, year: {row[3]}, range: {row[4]}, topSpeed: {row[5]}, zeroSixty: {row[6]}, mileage: {row[7]}')  
            currentVehicle = copy.deepcopy(myVehicle)  
            currentVehicle["vin"] = row[0]  
            currentVehicle["make"] = row[1]  
            currentVehicle["model"] = row[2]  
            currentVehicle["year"] = row[3]  
            currentVehicle["range"] = row[4]  
            currentVehicle["topSpeed"] = row[5]  
            currentVehicle["zeroSixty"] = row[6]  
            currentVehicle["mileage"] = row[7]  
            myInventoryList.append(currentVehicle)  
            lineCount += 1  
    print(f'Processed {lineCount} lines.')
    currentVehicle = copy.deepcopy(myVehicle)
    
    print("Printing the car inventory")
    for myCarProperties in myInventoryList:
        for key, value in myCarProperties.items():
            print("{} : {}".format(key,value))
            print("-----")
     
     
print("\n")            
print("Rubric: 7 - Conditionals")
print("Exercise 1: Working with the if statement")
#import string
x = input("Do you need to ship a package? (Enter yes or no) ")
userReply = x.upper() 
if userReply == "YES":
    print("We can help you ship that package!")

    print("Exercise 2: Working with the else statement")
else:
    print("Please come back when you need to ship a package. Thank you.")
    

print("Exercise 3: Working with the elif statement")
userReply = input("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy) ")
if userReply == "stamps":
    print("We have many stamp designs to choose from.")
elif userReply == "envelope":
    print("We have many envelope sizes to choose from.")
elif userReply == "copy":
    copies = input("How many copies would you like? (Enter a number) ")
    print("Here are {} copies.".format(copies))
else:
    print("Thank you, please come again.")    
    
print("\n")
print("Rubric: 8 - Loops ")
print("Exercise 1: Working with a while loop")
print("Printing the game rules")
print("Welcome to Guess the Number!")
print("The rules are simple. I will think of a number, and you will try to guess it.")
import random
number = random.randint(1,10)
isGuessRight = False
while isGuessRight != True:
    guess = input("Guess a number between 1 and 10: ")
    if int(guess) == number:
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    else:
        print("You guessed {}. Sorry, that isn’t it. Try again.".format(guess))
